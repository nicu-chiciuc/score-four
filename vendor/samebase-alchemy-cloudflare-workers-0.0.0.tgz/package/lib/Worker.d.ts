import * as workers from "@distilled.cloud/cloudflare/workers";
import { Resource } from "alchemy";
import * as Provider from "alchemy/Provider";
import type { Providers } from "./Providers.ts";
export interface WorkerProps {
    /**
     * Worker name: lowercase letters, digits, and dashes. With Worker Previews,
     * at most 54 characters. It must match `name` in the repository's Wrangler
     * file. A new name replaces the Worker.
     */
    readonly name: string;
    /**
     * `workers.dev` route and preview URLs.
     * @default { enabled: true, previewsEnabled: true }
     */
    readonly subdomain?: {
        readonly enabled: boolean;
        readonly previewsEnabled: boolean;
    };
    /** Workers Logs and traces. The default enables persisted invocation logs and disables traces. */
    readonly observability?: workers.BetaWorkersCreateRequestObservability;
    /** @default false */
    readonly logpush?: boolean;
    /** @default [] */
    readonly tags?: readonly string[];
    /** Workers that receive this Worker's logs. @default [] */
    readonly tailConsumers?: readonly {
        readonly name: string;
    }[];
    /**
     * Delete the Worker on destroy or replacement. Deleting a Worker deletes
     * every deployed version and all of its preview URLs. When this is not
     * `true`, destroy only removes the Worker from Alchemy state.
     * @default false
     */
    readonly delete?: boolean;
}
export interface WorkerAttributes {
    /** The Worker's immutable id. Workers Builds calls it the Worker tag or `script_tag`. */
    readonly workerId: string;
    readonly name: string;
    /**
     * `https://<name>.<account subdomain>.workers.dev`, or `undefined` when the
     * account has no `workers.dev` subdomain. It serves only while the
     * `workers.dev` route is enabled.
     */
    readonly url: string | undefined;
    readonly accountId: string;
}
/**
 * A Worker without code, for Workers Builds to deploy into.
 *
 * Wrangler also writes some Worker settings on each `wrangler deploy`:
 * `observability`, `logpush`, `workers_dev` (here `subdomain.enabled`), and
 * `preview_urls` (here `subdomain.previewsEnabled`). The Workers API also
 * accepts `tags` and `tail_consumers`. Each prop you set here is written on
 * create and on every update. Each prop you leave out gets its default on
 * create and is never written again. So when the Wrangler file
 * names a setting, leave that setting out of this resource; then the two
 * never fight.
 *
 * Destroy keeps the Worker unless `delete` is `true`.
 */
export type Worker = Resource<"WorkersBuilds.Worker", WorkerProps, WorkerAttributes, never, Providers>;
export declare const Worker: import("alchemy").ResourceClass<Worker>;
/** Observability on create when the prop is absent: persisted invocation logs, no traces. */
export declare const DEFAULT_OBSERVABILITY: workers.BetaWorkersCreateRequestObservability;
/** The create request: props over the defaults. */
export declare const createRequest: (accountId: string, props: WorkerProps) => workers.CreateBetaWorkerRequest;
/**
 * The PATCH body: only the settings the props name. PATCH leaves every
 * omitted setting unchanged, so a setting that Wrangler owns stays as the
 * last deploy wrote it.
 */
export declare const editBody: (props: WorkerProps) => Record<string, unknown>;
export declare const workersDevUrl: (name: string, subdomain: string | undefined) => string | undefined;
/** A new name or another account is a new Worker; anything else is an edit. */
export declare const diffWorker: (input: {
    readonly olds: WorkerProps;
    readonly news: WorkerProps;
    readonly output: WorkerAttributes | undefined;
    readonly accountId: string;
}) => {
    readonly action: "replace";
} | undefined;
export declare const WorkerProvider: () => import("effect/Layer").Layer<Provider.Provider<Worker>, never, import("alchemy/Cloudflare/CloudflareEnvironmentService").CloudflareEnvironment | workers.CloudflareOpContext>;
//# sourceMappingURL=Worker.d.ts.map