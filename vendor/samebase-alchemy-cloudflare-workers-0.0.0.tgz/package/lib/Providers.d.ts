import * as Provider from "alchemy/Provider";
import * as Layer from "effect/Layer";
declare const Providers_base: Provider.ProviderCollection<Providers, "WorkersBuilds">;
export declare class Providers extends Providers_base {
}
/**
 * Both Workers Builds providers. Credentials and the account come from
 * Alchemy's Cloudflare login, the same way as for `Cloudflare.providers()`.
 * The engine runs provider handlers with the stack's services, so the
 * Cloudflare credentials and account are merged into this layer's output,
 * as `Cloudflare.providers()` does.
 */
export declare const providers: () => Layer.Layer<import("alchemy/Cloudflare/CloudflareEnvironmentService").CloudflareEnvironment | import("@distilled.cloud/cloudflare/Credentials").Credentials | Providers | import("alchemy/Auth/Profile").ProfileStore | import("alchemy/Auth/Credentials").CredentialsStore | import("alchemy/Cloudflare/Access").Access, never, import("effect/http/HttpClient").HttpClient | import("effect/process/ChildProcessSpawner").ChildProcessSpawner | import("effect/Crypto").Crypto | import("effect/FileSystem").FileSystem | import("effect/Path").Path | import("alchemy").AuthProviders>;
export {};
//# sourceMappingURL=Providers.d.ts.map