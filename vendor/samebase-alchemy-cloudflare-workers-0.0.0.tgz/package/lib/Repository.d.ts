import * as workersBuilds from "@distilled.cloud/cloudflare/workers_builds";
import { Resource } from "alchemy";
import * as Provider from "alchemy/Provider";
import * as Config from "effect/Config";
import * as Effect from "effect/Effect";
import * as Redacted from "effect/Redacted";
import * as Schema from "effect/Schema";
import * as HttpClient from "effect/http/HttpClient";
import { WorkersBuildsError } from "./Api.ts";
import type { Providers } from "./Providers.ts";
export type BuildVariables = Readonly<Record<string, string | Redacted.Redacted<string>>>;
export interface GitHubRepository {
    /** Owner login, such as `samebase`. */
    readonly owner: string;
    /** Repository name without the owner. */
    readonly name: string;
    /** Production branch. Pushes to other branches build Worker Previews. */
    readonly branch: string;
    /**
     * Numeric GitHub id of the owner. With `repositoryId`, it skips the GitHub
     * lookup. Without both, the provider reads
     * `GET https://api.github.com/repos/{owner}/{name}` with `GITHUB_TOKEN` or
     * `GITHUB_ACCESS_TOKEN` when set, else without a token (public
     * repositories only).
     */
    readonly ownerId?: number;
    /** Numeric GitHub id of the repository. See `ownerId`. */
    readonly repositoryId?: number;
}
export interface RepositoryProps {
    /** Worker id (the Worker tag), such as `worker.workerId` of a `WorkersBuilds.Worker`. */
    readonly worker: string;
    /**
     * The GitHub repository. The Cloudflare Workers and Pages GitHub App must
     * have access to it. A different repository replaces the configuration; a
     * different branch is an update.
     */
    readonly repository: GitHubRepository;
    /** Build command, such as `pnpm run build`. */
    readonly buildCommand: string;
    /** Production deploy command. @default "npx wrangler deploy" */
    readonly deployCommand?: string;
    /**
     * Deploy command for every other branch. Worker Previews need a command
     * that runs `wrangler preview`.
     * @default "npx wrangler preview"
     */
    readonly previewDeployCommand?: string;
    /** Directory where the commands run, relative to the repository root. @default "/" */
    readonly rootDirectory?: string;
    /** Paths whose changes start a build. @default ["*"] */
    readonly pathIncludes?: readonly string[];
    /** Paths whose changes never start a build. @default [] */
    readonly pathExcludes?: readonly string[];
    /** @default true */
    readonly buildCachingEnabled?: boolean;
    /**
     * Build token uuid. Builds deploys with the API token behind it. Without
     * it, a new configuration uses the account's first build token (by name,
     * newest first), and an existing configuration keeps its token.
     */
    readonly buildToken?: string;
    /**
     * Worker Previews: one preview deployment and URL per branch. A
     * configuration that Cloudflare creates with legacy branch triggers is
     * migrated to Worker Previews.
     * @default true
     */
    readonly previews?: boolean;
    /**
     * Build variables for production and preview builds. `Redacted` values are
     * written as secrets: Cloudflare stores them and never returns them.
     * Removing a key here removes the variable on the next deploy.
     */
    readonly variables?: BuildVariables;
    /**
     * Build variables for preview builds only. A key here replaces the same key
     * of `variables` in preview builds, such as a preview deploy key.
     */
    readonly previewVariables?: BuildVariables;
}
export interface RepositoryAttributes {
    /** The Worker tag that the configuration belongs to. */
    readonly scriptTag: string;
    /** Repository connection uuid, shared by every Worker that builds from the repository. */
    readonly repoConnectionId: string | undefined;
    /** Uuids of the active build triggers, sorted. */
    readonly triggerIds: readonly string[];
    readonly previewsEnabled: boolean;
    readonly accountId: string;
}
/**
 * The Workers Builds configuration that connects a GitHub repository to a
 * Worker.
 *
 * Destroy removes the triggers and the build configuration. It keeps the
 * Worker and the repository connection: Cloudflare shares one connection
 * between every Worker that builds from the same repository.
 */
export type Repository = Resource<"WorkersBuilds.Repository", RepositoryProps, RepositoryAttributes, never, Providers>;
export declare const Repository: import("alchemy").ResourceClass<Repository>;
export declare const DEFAULT_DEPLOY_COMMAND = "npx wrangler deploy";
export declare const DEFAULT_PREVIEW_DEPLOY_COMMAND = "npx wrangler preview";
/**
 * The fields of `/builds/workers` results that the provider reads. Recorded
 * payloads: test/fixtures/cloudflare/builds_workers_*.json.
 */
export declare const WorkerBuilds: Schema.Struct<{
    readonly script_tag: Schema.String;
    readonly git_repository: Schema.Struct<{
        readonly provider_type: Schema.String;
        readonly repo_id: Schema.String;
        readonly repo_name: Schema.String;
        readonly provider_account_name: Schema.String;
    }>;
    readonly previews_enabled: Schema.Boolean;
    readonly production_settings: Schema.Struct<{
        readonly build_token_uuid: Schema.String;
    }>;
}>;
export type WorkerBuilds = typeof WorkerBuilds.Type;
/** The fields of GET https://api.github.com/repos/{owner}/{name} that the provider reads. */
export declare const GitHubRepositoryResponse: Schema.Struct<{
    readonly id: Schema.Number;
    readonly owner: Schema.Struct<{
        readonly id: Schema.Number;
    }>;
}>;
export interface RepositoryIds {
    readonly ownerId: string;
    readonly repositoryId: string;
}
/** POST /accounts/{account_id}/builds/workers. Holds secret values; never log it. */
export declare const createBody: (input: {
    readonly scriptTag: string;
    readonly props: RepositoryProps;
    readonly ids: RepositoryIds;
    readonly buildToken: string;
}) => {
    script_tag: string;
    git_repository: {
        provider_type: string;
        provider_account_id: string;
        provider_account_name: string;
        repo_id: string;
        repo_name: string;
        branch: string;
    };
    production_settings: {
        build_command: string;
        deploy_command: string;
        root_directory: string;
        path_includes: string[];
        path_excludes: string[];
        build_caching_enabled: boolean;
        build_token_uuid: string;
        environment_variables: object;
    };
    previews_base_config: {
        build_command: string;
        deploy_command: string;
        root_directory: string;
        path_includes: string[];
        path_excludes: string[];
        build_caching_enabled: boolean;
        build_token_uuid: string;
        environment_variables: object;
    };
    previews_enabled: boolean;
};
/**
 * PATCH /accounts/{account_id}/builds/workers/{script_tag}. Variables that
 * `olds` declared and `news` drops are sent as `null`, which removes them.
 * Variables that someone else added stay. Holds secret values; never log it.
 */
export declare const updateBody: (input: {
    readonly news: RepositoryProps;
    readonly olds: RepositoryProps | undefined;
    readonly buildToken: string;
}) => {
    git_repository: {
        branch: string;
    };
    production_settings: {
        build_command: string;
        deploy_command: string;
        root_directory: string;
        path_includes: string[];
        path_excludes: string[];
        build_caching_enabled: boolean;
        build_token_uuid: string;
        environment_variables: object;
    };
    previews_base_config: {
        build_command: string;
        deploy_command: string;
        root_directory: string;
        path_includes: string[];
        path_excludes: string[];
        build_caching_enabled: boolean;
        build_token_uuid: string;
        environment_variables: object;
    };
    previews_enabled: boolean;
};
/**
 * Another Worker, repository, or account is a new configuration; anything
 * else is an update. GitHub names are case-insensitive. Adding the numeric
 * ids of the same repository is an update.
 */
export declare const diffRepository: (input: {
    readonly olds: RepositoryProps;
    readonly news: RepositoryProps;
    readonly output: RepositoryAttributes | undefined;
    readonly accountId: string;
}) => {
    readonly action: "replace";
} | undefined;
/** Sorted like the Samebase token picker: name descending, then uuid. */
export declare const selectBuildToken: (tokens: readonly workersBuilds.ListTokensResultItem[]) => string | undefined;
/** Active triggers and their repository connection, in a stable order. */
export declare const triggerAttributes: (triggers: readonly workersBuilds.ListTriggersResultItem[]) => {
    triggerIds: string[];
    repoConnectionId: string | undefined;
};
export declare const RepositoryProvider: () => import("effect/Layer").Layer<Provider.Provider<Repository>, never, import("alchemy/Cloudflare/CloudflareEnvironmentService").CloudflareEnvironment | workersBuilds.CloudflareOpContext>;
/** The numeric GitHub ids that Workers Builds addresses a repository by. */
export declare const resolveRepositoryIds: (repository: GitHubRepository) => Effect.Effect<{
    ownerId: string;
    repositoryId: string;
}, WorkersBuildsError | Config.ConfigError, HttpClient.HttpClient>;
//# sourceMappingURL=Repository.d.ts.map