import { Credentials } from "@distilled.cloud/cloudflare/Credentials";
import { CloudflareEnvironment } from "alchemy/Cloudflare";
import * as Effect from "effect/Effect";
import * as Schema from "effect/Schema";
import * as HttpClient from "effect/http/HttpClient";
/** Token permissions that the Worker shell and the Builds endpoints need. */
export declare const TOKEN_PERMISSIONS: readonly ["Workers Builds Configuration: Edit", "Workers Scripts: Edit", "Account Settings: Read"];
declare const PermissionError_base: Schema.Class<PermissionError, Schema.TaggedStruct<"WorkersBuildsPermissionError", {
    readonly operation: Schema.String;
    readonly reason: Schema.String;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/**
 * Cloudflare refused a call for lack of permission. The usual cause is
 * Alchemy's OAuth login, which has no Workers Builds scope.
 */
export declare class PermissionError extends PermissionError_base {
}
declare const WorkersBuildsError_base: Schema.Class<WorkersBuildsError, Schema.TaggedStruct<"WorkersBuildsError", {
    readonly operation: Schema.String;
    readonly status: Schema.optionalKey<Schema.Number>;
    readonly code: Schema.optionalKey<Schema.Number>;
    readonly message: Schema.String;
}>, import("effect/Cause").YieldableError>;
/** Any other failed call. `status` and `code` come from the Cloudflare response when it has them. */
export declare class WorkersBuildsError extends WorkersBuildsError_base {
}
/**
 * Maps the permission failures of a `@distilled.cloud/cloudflare` call to
 * {@link PermissionError}. Distilled turns HTTP 401 into `Unauthorized` and
 * HTTP 403 into `Forbidden`.
 */
export declare const refused: (operation: string) => <A, E extends {
    readonly _tag: string;
    readonly code?: number | undefined;
}, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A, E | PermissionError, R>;
/** The account the stack deploys into, from Alchemy's Cloudflare profile or environment. */
export declare const currentAccountId: Effect.Effect<string, never, CloudflareEnvironment>;
export interface CloudflareRequest<A> {
    readonly operation: string;
    readonly method: "GET" | "POST" | "PATCH" | "DELETE";
    /** Path after the API base URL, such as `/accounts/<id>/builds/workers`. */
    readonly path: string;
    readonly query?: Readonly<Record<string, string>>;
    readonly body?: object;
    /** Schema of the envelope's `result`. */
    readonly result: Schema.Decoder<A>;
}
/**
 * One Cloudflare API call with the stack's Cloudflare credentials. Returns
 * the decoded `result`. Fails with {@link PermissionError} for HTTP 401,
 * HTTP 403, or error 12006, and otherwise with {@link WorkersBuildsError},
 * which keeps the first error's code and message. The body can hold
 * secrets; never log it.
 */
export declare const cloudflareRequest: <A>(request: CloudflareRequest<A>) => Effect.Effect<A, PermissionError | WorkersBuildsError | import("@distilled.cloud/cloudflare/Credentials").CredentialsError, HttpClient.HttpClient | Credentials>;
/**
 * Turns "not found" into `undefined` so read and delete stay idempotent:
 * HTTP 404, or one of the endpoint's not-found error `codes`.
 */
export declare const absentAsUndefined: (codes: readonly number[]) => <A, E, R>(effect: Effect.Effect<A, E, R>) => Effect.Effect<A | undefined, E, R>;
/**
 * Distilled answers HTTP 404 with `NotFound` at runtime, although the
 * declared error unions of its Workers Builds operations leave that class out.
 */
export declare const isNotFound: (error: {
    readonly _tag: string;
}) => boolean;
export {};
//# sourceMappingURL=Api.d.ts.map